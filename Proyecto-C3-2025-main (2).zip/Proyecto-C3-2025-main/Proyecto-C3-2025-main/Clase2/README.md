# Proyecto-C3-2025
## Subtitulo
### Subtitulo de segundo nivel
JAENS / CENFOTEC

**Negrita**

- item1
- item2
- item3

1. Paso 1
2. Paso 2
3. Paso 3


**Cursiva**


####Bloque de código
```javascript
function myFunction() {
  console.log('Hola mundo');
}

myFunction();

```

#### Tablas
| Nombre | Apellido | Edad |
| ------ | -------- | ---- |
| Juan   | Perez    | 25   |
| Pedro  | Rodriguez| 30   |

#### Listas
- item1
- item2
- item3

#### Links
[GitHub](https://github.com)

#### Imágenes
![Imagen](https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png)


